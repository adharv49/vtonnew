<?php
$con = mysqli_connect("localhost","root", "password", "threaderz_store");
?>